package edu.mum.mpp.lesson10;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class TestTDDPractice {
	
	TDDPractice tdd = new TDDPractice();
	@Test
	public void testChangeLastCharToUpper()
	{
		List<String> words = new ArrayList<>();
		words.add("Lukman");
		words.add("Ademola");
		words.add("Arogundade");
		
		List<String> tempList = TDDPractice.changeLastCharToUpper(words);
		
		assert (!tempList.isEmpty()) ;
		
	}

}
