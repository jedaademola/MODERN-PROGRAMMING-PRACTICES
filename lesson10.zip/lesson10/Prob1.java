package edu.mum.mpp.lesson10;

public class Prob1 {

}
