package edu.mum.mpp.lesson10.prob6;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
