package edu.mum.mpp.lesson10;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TDDPractice {

	public static void main(String[] args) {
		//comments
		/*
		 * The test failed when the list was empty
		 It is a good approach since the output could be tested before the actual implementation
		 */
		
		List<String> words = new ArrayList<>();
		words.add("Lukman");
		words.add("Ademola");
		words.add("Arogundade");
		
		List<String> l = changeLastCharToUpper(words);
		
		l.forEach(s -> System.out.println(s));

	}

	
	public static List<String>  changeLastCharToUpper(List<String> words)
	{
		//List<String> tempList = new ArrayList<>();
		
		List<String> tempList = words.stream()
				.map(s -> s.substring(0, s.length() - 1) + s.substring(s.length() - 1).toUpperCase())
				.collect(Collectors.toList());
		
		return tempList;
		
	}
}
